import * as THREE from 'three';
import { BadgeUnlockSequence, UnlockState, BADGE_UNLOCK_CONFIG } from './BadgeUnlockSequence.js';
import { mountUnlockDebug } from './BadgeUnlockDebug.js';
import { SVGLoader } from 'three/addons/loaders/SVGLoader.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { toCreasedNormals } from 'three/addons/utils/BufferGeometryUtils.js';

const canvas = /** @type {HTMLCanvasElement} */ (document.querySelector('#scene'));
const rotateButton = /** @type {HTMLButtonElement} */ (document.querySelector('#rotate'));
const resetButton = /** @type {HTMLButtonElement} */ (document.querySelector('#reset'));
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const state = { dragging: false, auto: false, yaw: -0.16, pitch: 0.055, targetYaw: -0.16, targetPitch: 0.055, lastX: 0, lastY: 0, velocity: 0, pointer: null };
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 80);
const badge = new THREE.Group();
badge.scale.setScalar(0.5);
scene.add(badge);
let renderer, composer, bloom, background, environmentTarget, unlockSequence;
const atmosphere = [];
const lifecycle = new AbortController();
let resizeObserver;
const interactionAllowed = () => !unlockSequence || unlockSequence.disposed || unlockSequence.ui.dataset.unlockReady === 'true';

function physical(options, scatter = 0) {
  const material = new THREE.MeshPhysicalMaterial(options);
  // Neutral, thickness-inspired diffusion underneath polished silver.
  // The specular BRDF and bevel reflections remain physically based.
  if (scatter) {
    material.onBeforeCompile = shader => {
      shader.fragmentShader = shader.fragmentShader.replace('#include <opaque_fragment>', `
        float facing = clamp(dot(normalize(normal), normalize(vViewPosition)), 0.0, 1.0);
        float wrap = pow(1.0 - facing, 2.0);
        vec3 diffusion = vec3(0.17) * (${scatter.toFixed(3)}) * (0.16 + wrap * 0.65);
        outgoingLight += diffusion;
        #include <opaque_fragment>
      `);
    };
    material.customProgramCacheKey = () => `badge-diffusion-${scatter}`;
  }
  return material;
}

const materials = {
  body: physical({ color: '#c4c4c4', metalness: 0.95, roughness: 0.26, envMapIntensity: 0.85, clearcoat: 0.45, clearcoatRoughness: 0.1 }),
  edge: physical({ color: '#f2f2f2', metalness: 0.68, roughness: 0.27, envMapIntensity: 1.05, emissive: '#d8d8d8', emissiveIntensity: 0.055, clearcoat: 0.8, clearcoatRoughness: 0.075 }),
  star: physical({ color: '#ffffff', metalness: 0.58, roughness: 0.29, envMapIntensity: 0.95, emissive: '#ffffff', emissiveIntensity: 0.16, clearcoat: 0.8, clearcoatRoughness: 0.085 }, 0.3),
  starEdge: physical({ color: '#ffffff', metalness: 0.6, roughness: 0.085, envMapIntensity: 1.25, emissive: '#ffffff', emissiveIntensity: 0.6, clearcoat: 1, clearcoatRoughness: 0.035 }),
  starHighlight: physical({ color: '#ffffff', metalness: 0.45, roughness: 0.07, envMapIntensity: 1.1, emissive: '#ffffff', emissiveIntensity: 1.15, clearcoat: 1, clearcoatRoughness: 0.025 }),
  inset: physical({ color: '#767676', metalness: 0.68, roughness: 0.43, envMapIntensity: 0.6, clearcoat: 0.3, clearcoatRoughness: 0.2 }),
  rim: physical({ color: '#cacaca', metalness: 0.8, roughness: 0.24, envMapIntensity: 0.92, clearcoat: 0.7, clearcoatRoughness: 0.09 }),
  letters: physical({ color: '#ffffff', metalness: 0.5, roughness: 0.26, envMapIntensity: 0.8, emissive: '#ffffff', emissiveIntensity: 0.14, clearcoat: 0.45, clearcoatRoughness: 0.1 }),
  reverse: physical({ color: '#d8d8d8', metalness: 0.66, roughness: 0.43, envMapIntensity: 0.7, clearcoat: 0.25, clearcoatRoughness: 0.24 }),
  reverseLetters: physical({ color: '#606060', metalness: 0.18, roughness: 0.78, envMapIntensity: 0.16, clearcoat: 0 }),
};

function buildEnvironment() {
  const studio = new THREE.Scene();
  studio.background = new THREE.Color('#686868');
  function softbox(w, h, position, color, intensity) {
    const light = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(intensity), side: THREE.DoubleSide }));
    light.position.set(...position);
    light.lookAt(0, 0, 0);
    studio.add(light);
  }
  // Long, narrow studio panels produce real moving highlight lines on the bevels.
  softbox(0.65, 9, [-4, 2, 5], '#ffffff', 5.5);
  softbox(0.3, 8, [4.1, 0.3, 3.8], '#ffffff', 7);
  softbox(7, 0.4, [0, 5, 2.8], '#ffffff', 6);
  softbox(6, 5.5, [-0.5, 1, 6.5], '#ffffff', 1.3);
  softbox(3, 5.5, [4.8, 1, -2.5], '#ffffff', 1.4);
  softbox(1, 5, [-4, -1, -3], '#ffffff', 1.8);
  softbox(6, 1, [0, -4, 3], '#ffffff', 1.2);
  softbox(6, 5, [0, 2, -6], '#ffffff', 1.6);
  const pmrem = new THREE.PMREMGenerator(renderer);
  environmentTarget = pmrem.fromScene(studio, 0.025, 0.1, 100);
  scene.environment = environmentTarget.texture;
  studio.traverse(object => { object.geometry?.dispose(); object.material?.dispose(); });
  pmrem.dispose();
  scene.add(new THREE.HemisphereLight('#ffffff', '#707070', 0.75));
  const key = new THREE.DirectionalLight('#ffffff', 1.8);
  key.position.set(-3.5, 5, 5);
  scene.add(key);
  const fill = new THREE.DirectionalLight('#ffffff', 0.7);
  fill.position.set(4, 1, 2.5);
  scene.add(fill);
  const rim = new THREE.DirectionalLight('#ffffff', 1.35);
  rim.position.set(1, 3, -4);
  scene.add(rim);
}

function buildAtmosphere() {
  background = new THREE.ShaderMaterial({
    depthTest: false, depthWrite: false, toneMapped: false,
    uniforms: { uTime: { value: 0 }, uAspect: { value: 1 } },
    vertexShader: `varying vec2 vUv; void main(){vUv=uv;gl_Position=vec4(position.xy,0.9999,1.0);}`,
    fragmentShader: `
      varying vec2 vUv; uniform float uTime; uniform float uAspect;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.0),f.x),f.y);}
      float beam(vec2 uv,float origin,float angle,float width){float dy=1.18-uv.y;float x=(uv.x-origin)*uAspect-angle*dy;return exp(-pow(x/(width+dy*0.095),2.0))*exp(-dy*2.7);}
      void main(){
        vec2 uv=vUv; float t=uTime;
        vec2 p=(uv-vec2(.5,.8))*vec2(uAspect,1.0);
        vec3 col=vec3(.0006);
        col+=vec3(.007)*exp(-dot(p,p)*2.7);
        float mist=noise(uv*vec2(5.,7.)+vec2(t*.015,-t*.012));
        float rays=beam(uv,.20,.22,.035)*.63+beam(uv,.47,-.14,.045)*.72+beam(uv,.83,-.33,.03)*.65;
        col+=vec3(.040)*rays*(.76+.24*mist);
        vec2 halo=(uv-vec2(.5,.50))*vec2(uAspect,1.0);
        col+=vec3(.004)*exp(-dot(halo,halo)*13.0);
        vec2 floorGlow=(uv-vec2(.5,.175))*vec2(uAspect*1.45,10.5);
        col+=vec3(.022)*exp(-dot(floorGlow,floorGlow)*16.0);
        float vignette=smoothstep(.88,.15,length((uv-.5)*vec2(.92,.74)));
        col*=.55+.45*vignette;
        col=max(vec3(0.),col+(hash(gl_FragCoord.xy)-.5)*.0006);
        gl_FragColor=vec4(col,1.0);
      }`
  });
  const backdrop = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), background);
  backdrop.frustumCulled = false;
  backdrop.renderOrder = -100;
  scene.add(backdrop);atmosphere.push(backdrop);
  // Fine neutral specks give the white shafts depth.
  const positions = [], phases = [], sizes = [];
  let seed = 29;
  const random = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  for (let i=0;i<78;i++) {
    positions.push((random()-.5)*11,(random()-.5)*8,-2-random()*6);
    phases.push(random()*6.28); sizes.push(1.0+random()*1.8);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('phase',new THREE.Float32BufferAttribute(phases,1));
  geometry.setAttribute('size',new THREE.Float32BufferAttribute(sizes,1));
  const dust = new THREE.ShaderMaterial({
    transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
    uniforms:{uTime:background.uniforms.uTime},
    vertexShader:`attribute float phase;attribute float size;uniform float uTime;varying float vAlpha;void main(){vec3 p=position;p.x+=sin(uTime*.13+phase)*.09;p.y+=sin(uTime*.08+phase*2.)*.13;vec4 mv=modelViewMatrix*vec4(p,1.);gl_Position=projectionMatrix*mv;gl_PointSize=size*14./-mv.z;vAlpha=.15+.22*(.5+.5*sin(phase+uTime*.4));}`,
    fragmentShader:`varying float vAlpha;void main(){float d=length(gl_PointCoord-.5);float a=exp(-d*d*22.)*vAlpha;gl_FragColor=vec4(.75,.75,.75,a);}`
  });
  const specks=new THREE.Points(geometry,dust);scene.add(specks);atmosphere.push(specks);
}

// Source coordinates are kept intact. Only an affine centre/scale is applied
// per face; every SVG path, stroke, hole and nested group is retained.
const SCALE = 3.4 / 262.90991;
const FRONT = { x:777.316635, y:549.400815 };
const BACK = { x:1142.710445, y:551.272355 };
const HALF_THICKNESS = 0.037;

function toFaceGeometry(geometry, center, scale = SCALE) {
  geometry.translate(-center.x,-center.y,0);
  geometry.scale(scale,-scale,1);
  // Mirroring the SVG y axis changes triangle winding, but not the outward normal.
  const count=geometry.getAttribute('position').count;
  if (geometry.index) {
    const a=geometry.index.array;
    for(let i=0;i<a.length;i+=3) [a[i+1],a[i+2]]=[a[i+2],a[i+1]];
  } else {
    const indices=[];
    for(let i=0;i<count;i+=3) indices.push(i,i+2,i+1);
    geometry.setIndex(indices);
  }
  return geometry;
}

function extrude(shapes, center, depth, bevel, scale = SCALE, smooth = false) {
  const geometry=toFaceGeometry(new THREE.ExtrudeGeometry(shapes, {
    depth, steps:1, curveSegments:smooth?64:32, bevelEnabled:bevel>0,
    bevelThickness:bevel*scale, bevelSize:bevel, bevelSegments:smooth?8:4,
  }),center,scale);
  if(!smooth) return geometry;
  const result=geometry.toNonIndexed();
  geometry.dispose();
  const positions=result.getAttribute('position').clone();
  const originalNormals=result.getAttribute('normal');
  // Use a 0.00001-world-unit weld tolerance; the helper's default tolerance
  // is too coarse for shallow relief and could merge neighboring bevel rows.
  result.scale(1000,1000,1000);
  toCreasedNormals(result,0.5);
  result.setAttribute('position',positions);
  const normals=result.getAttribute('normal');
  // Retain flat silver faces and crisp artwork; smooth only the curved edges.
  for(const group of result.groups) if(group.materialIndex===0) {
    normals.array.set(originalNormals.array.subarray(group.start*3,(group.start+group.count)*3),group.start*3);
  }
  result.boundingBox=null; result.boundingSphere=null;
  return result;
}

function addStarHighlight(path, center, parent, height) {
  // Trace the supplied star contour exactly at the crest of its shallow bevel.
  // This narrow white reflection stays crisp even when a mirror bevel faces
  // the dark stage, rather than turning the star outline into a black seam.
  for(const sub of path.subPaths) {
    const points=sub.getPoints(64);
    if(points.length<3) continue;
    if(points[0].distanceToSquared(points.at(-1))>1e-10) points.push(points[0].clone());
    const curve=new THREE.CurvePath();
    for(let i=1;i<points.length;i++) {
      const a=points[i-1],b=points[i];
      if(a.distanceToSquared(b)<1e-12) continue;
      curve.add(new THREE.LineCurve3(
        new THREE.Vector3((a.x-center.x)*SCALE,(center.y-a.y)*SCALE,0),
        new THREE.Vector3((b.x-center.x)*SCALE,(center.y-b.y)*SCALE,0)
      ));
    }
    const geometry=new THREE.TubeGeometry(curve,Math.max(768,points.length),.22*SCALE,8,true);
    geometry.scale(1,1,.34);
    const line=new THREE.Mesh(geometry,materials.starHighlight);
    line.position.z=height+.0007;
    line.name='White highlight on original star contour';
    parent.add(line);
  }
}

async function buildBadge() {
  const [source, backSource] = await Promise.all(['./assets/badge.svg','./assets/badge-back.svg'].map(url =>
    fetch(url).then(r => { if(!r.ok) throw new Error('SVG unavailable'); return r.text(); })
  ));
  const data = new SVGLoader().parse(source);
  const backData = new SVGLoader().parse(backSource);
  const root = data.xml;
  const children=Array.from(root.children);
  const faceFront=new THREE.Group(); faceFront.name='SVG front';
  const faceBack=new THREE.Group(); faceBack.name='SVG back'; faceBack.rotation.y=Math.PI;
  badge.add(faceFront,faceBack);
  const bodyPath=data.paths.find(p=>p.userData.node===children[9]);
  const silhouette=SVGLoader.createShapes(bodyPath);
  const body=new THREE.Mesh(extrude(silhouette,BACK,HALF_THICKNESS*2-0.008,0.66,SCALE,true),[materials.body,materials.edge]);
  body.position.z=-HALF_THICKNESS+0.004;
  body.name='Thin solid metal substrate'; badge.add(body);
  const groups=new WeakMap();
  function parentGroup(node,face,sourceRoot=root) {
    if(node===sourceRoot || !node || node.parentNode===sourceRoot) return face;
    if(groups.has(node)) return groups.get(node);
    const group=new THREE.Group(); group.name=node.id || node.tagName;
    parentGroup(node.parentNode,face,sourceRoot).add(group); groups.set(node,group); return group;
  }
  let paths=0, strokes=0;
  for(const path of data.paths) {
    const node=path.userData.node;
    let top=node; while(top.parentNode!==root) top=top.parentNode;
    const index=children.indexOf(top), back=index>=9;
    if(back) continue;
    const face=back?faceBack:faceFront, center=back?BACK:FRONT;
    const parent=parentGroup(node.parentNode,face);
    const style=path.userData.style;
    let material=materials.letters, depth=.006, bevel=.07, z=HALF_THICKNESS+.014;
    if(index===1) {material=materials.star;depth=.018;bevel=.47;z=HALF_THICKNESS-.002;}
    if(index===2||index===6) {material=materials.inset;depth=.006;bevel=.23;z=HALF_THICKNESS-.003;}
    if(index===3) {material=materials.rim;depth=.010;bevel=.48;z=HALF_THICKNESS;}
    if(index===4||index===5) {depth=.005;bevel=.065;z=HALF_THICKNESS+.014;}
    if(index===7||index===8) {z=HALF_THICKNESS+.005;depth=.005;bevel=.06;}
    if(style.fill!=='none'&&style.fillOpacity!==0) {
      const shapes=SVGLoader.createShapes(path);
      if(shapes.length) {
        const edgeMaterial=index===1?materials.starEdge:materials.edge;
        const mesh=new THREE.Mesh(extrude(shapes,center,depth,bevel,SCALE,index<=6),[material,edgeMaterial]);
        mesh.position.z=z; mesh.name=`SVG ${node.tagName} ${paths++}`; parent.add(mesh);
        if(index===1) addStarHighlight(path,center,parent,z+depth+bevel*SCALE);
      }
    }
    if(style.stroke&&style.stroke!=='none'&&style.strokeOpacity!==0) {
      for(const sub of path.subPaths) {
        // Flattened round metal wires preserve the SVG's exact stroke centreline
        // and width, with a shallow rounded highlight instead of a flat decal.
        const points=sub.getPoints(80);
        const curve=new THREE.CurvePath();
        for(let i=1;i<points.length;i++) {
          const a=points[i-1],b=points[i]; if(a.distanceToSquared(b)<1e-12) continue;
          curve.add(new THREE.LineCurve3(new THREE.Vector3((a.x-center.x)*SCALE,(center.y-a.y)*SCALE,0),new THREE.Vector3((b.x-center.x)*SCALE,(center.y-b.y)*SCALE,0)));
        }
        if(!curve.curves.length) continue;
        const geo=new THREE.TubeGeometry(curve,Math.max(96,points.length),Number(style.strokeWidth)*SCALE/2,8,false);
        geo.scale(1,1,.21);
        const mesh=new THREE.Mesh(geo,materials.letters); mesh.position.z=z+.003;
        mesh.name=`SVG stroke ${strokes++}`; parent.add(mesh);
      }
    }
  }
  // The supplied standalone reverse is the sole source of its artwork.
  // Align its own outline to the unchanged metal body; do not retype glyphs.
  const backRoot=backData.xml;
  const backPlate=backData.paths.find(path=>path.userData.node===backRoot.children[0]);
  const backBounds=new THREE.Box2().setFromPoints(backPlate.subPaths.flatMap(path=>path.getPoints(32)));
  const backCenter=backBounds.getCenter(new THREE.Vector2());
  const backScale=3.4/backBounds.getSize(new THREE.Vector2()).y;
  for(const path of backData.paths) {
    if(path.userData.style.fill==='none'||path.userData.style.fillOpacity===0) continue;
    const plate=path===backPlate;
    const shapes=SVGLoader.createShapes(path);
    if(!shapes.length) continue;
    const material=plate?materials.reverse:materials.reverseLetters;
    const mesh=new THREE.Mesh(
      extrude(shapes,backCenter,plate ? .004 : .002,plate ? .16 : .02,backScale,plate),
      [material,plate?materials.edge:materials.reverseLetters]
    );
    mesh.position.z=HALF_THICKNESS+(plate?-.001:.006);
    mesh.name=`Reverse SVG ${path.userData.node.tagName} ${paths++}`;
    parentGroup(path.userData.node.parentNode,faceBack,backRoot).add(mesh);
  }
  badge.userData={sourcePaths:paths+strokes,filledPaths:paths,strokes,backSource:'./assets/badge-back.svg',backSourcePaths:backData.paths.length,thickness:HALF_THICKNESS*2};
}

function setAuto(value) {
  state.auto=value; rotateButton.setAttribute('aria-pressed',String(value));
  rotateButton.setAttribute('aria-label',value?'暂停自动旋转':'开始自动旋转');
}
function reset() { setAuto(false);state.yaw=Math.atan2(Math.sin(state.yaw),Math.cos(state.yaw));state.targetYaw=0;state.targetPitch=0;state.velocity=0; }
rotateButton.addEventListener('click',()=>{if(interactionAllowed())setAuto(!state.auto);});
resetButton.addEventListener('click',reset);
canvas.addEventListener('pointerdown',event=>{
  if(!interactionAllowed()||state.pointer!==null||event.button!==0) return;
  state.pointer=event.pointerId;state.dragging=true;state.lastX=event.clientX;state.lastY=event.clientY;state.velocity=0;
  setAuto(false);canvas.setPointerCapture(event.pointerId);canvas.focus({preventScroll:true});
});
canvas.addEventListener('pointermove',event=>{
  if(!state.dragging||event.pointerId!==state.pointer) return;
  const dx=event.clientX-state.lastX,dy=event.clientY-state.lastY;
  state.targetYaw+=dx*.009;state.targetPitch=THREE.MathUtils.clamp(state.targetPitch+dy*.007,-1.4,1.4);
  state.velocity=THREE.MathUtils.clamp(dx*.004,-.055,.055);state.lastX=event.clientX;state.lastY=event.clientY;
});
function release(event){if(event.pointerId!==state.pointer)return;state.dragging=false;state.pointer=null;}
canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',release);canvas.addEventListener('lostpointercapture',release);
canvas.addEventListener('keydown',event=>{
  if(!interactionAllowed()) return;
  const moves={ArrowLeft:[-.15,0],ArrowRight:[.15,0],ArrowUp:[0,-.12],ArrowDown:[0,.12]};
  if(moves[event.key]) {event.preventDefault();setAuto(false);state.velocity=0;state.targetYaw+=moves[event.key][0];state.targetPitch=THREE.MathUtils.clamp(state.targetPitch+moves[event.key][1],-1.4,1.4);}
  if(event.key==='Home'||event.key==='Escape'){event.preventDefault();reset();}
});

function resize() {
  if(!renderer) return;
  const width=canvas.clientWidth,height=canvas.clientHeight;
  if(!width||!height) return;
  camera.aspect=width/height;
  // Keep the original 34 degree lens; the sequence computes its own screen anchor.
  camera.fov=34;
  const tangent=Math.tan(THREE.MathUtils.degToRad(camera.fov/2));
  camera.position.set(0,.06,Math.max(3.4/(2*tangent*.68),3.04/(2*tangent*camera.aspect*.84)));
  camera.lookAt(0,.06,0);camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(devicePixelRatio,Math.min(width,height)<BADGE_UNLOCK_CONFIG.particles.mobileBreakpoint?BADGE_UNLOCK_CONFIG.performance.mobileDpr:BADGE_UNLOCK_CONFIG.performance.desktopDpr));
  renderer.setSize(width,height,false);composer?.setPixelRatio(renderer.getPixelRatio());composer?.setSize(width,height);
  if(background)background.uniforms.uAspect.value=camera.aspect;
  if(unlockSequence&&!unlockSequence.disposed)unlockSequence.resize();
}

let previous=0,elapsed=0,lastRender=0;
function renderScene(){if(composer)composer.render();else renderer.render(scene,camera);}
function animate(now) {
  if(document.hidden||canvas.hidden) return;
  const realDt=previous?Math.max(0,(now-previous)/1000):0;previous=now;
  const dt=Math.min(realDt,.05);elapsed+=dt;
  unlockSequence?.update(realDt);
  if(interactionAllowed()) {
    if(state.auto) state.targetYaw+=dt*.34;
    else if(!state.dragging) {state.targetYaw+=state.velocity*dt*60;state.velocity*=Math.exp(-dt*7.5);}
    const damping=reducedMotion?1:1-Math.exp(-dt*15);
    state.yaw=THREE.MathUtils.lerp(state.yaw,state.targetYaw,damping);
    state.pitch=THREE.MathUtils.lerp(state.pitch,state.targetPitch,damping);
    badge.rotation.set(state.pitch,state.yaw,0,'YXZ');
  }
  background.uniforms.uTime.value=reducedMotion?0:elapsed;
  const playing=unlockSequence?.state===UnlockState.PLAYING;
  const fps=unlockSequence?.state===UnlockState.IDLE?BADGE_UNLOCK_CONFIG.performance.idleFps:BADGE_UNLOCK_CONFIG.performance.revealedFps;
  if(playing||state.dragging||state.auto||now-lastRender>=1000/fps) {renderScene();lastRender=now;}
}

async function createSequence(play=false) {
  unlockSequence?.dispose();
  canvas.style.visibility='hidden';
  /** @type {HTMLElement} */ (document.querySelector('.award-screen')).classList.add('unlock-active');
  resize();
  unlockSequence=new BadgeUnlockSequence({scene,camera,renderer,composer,bloom,badge,atmosphere,
    onUnlock(){setAuto(false);state.dragging=false;state.pointer=null;state.yaw=0;state.pitch=0;state.targetYaw=0;state.targetPitch=0;state.velocity=0;badge.rotation.set(0,0,0);window.dispatchEvent(new CustomEvent('badgeawarded'));},
    onReady(){canvas.tabIndex=0;setAuto(!unlockSequence.reduced);}, onRestore:resize});
  canvas.tabIndex=-1;
  document.querySelector('#preload-hint')?.remove();
  const prepared=await unlockSequence.prepare();
  canvas.style.visibility='';
  if(prepared&&play)unlockSequence.play();
  return prepared;
}

function showFallback(error) {
  if(error)console.error('Badge renderer could not start',error);
  unlockSequence?.dispose();
  renderer?.setAnimationLoop(null);
  document.querySelector('#preload-hint')?.remove();
  /** @type {HTMLElement} */ (document.querySelector('.award-screen')).classList.remove('unlock-active');
  /** @type {HTMLElement} */ (document.querySelector('.award-screen')).dataset.unlockState='REVEALED';
  /** @type {HTMLElement} */ (document.querySelector('#fallback')).hidden=false;
  /** @type {HTMLElement} */ (document.querySelector('.controls')).hidden=true;
  /** @type {HTMLElement} */ (document.querySelector('.award-copy')).inert=false;
  /** @type {HTMLElement} */ (document.querySelector('.award-actions')).inert=false;
  /** @type {HTMLButtonElement} */ (document.querySelector('#share-award')).disabled=false;
  /** @type {HTMLButtonElement} */ (document.querySelector('#confirm-award')).disabled=false;
  canvas.hidden=true;
  window.badgePresentation={reset,snapshot:()=>null};
}

try {
  renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,2));
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.91;
  buildEnvironment();buildAtmosphere();
  composer=new EffectComposer(renderer);
  const gl=renderer.getContext();
  const supportedSamples=gl.getInternalformatParameter(gl.RENDERBUFFER,gl.RGBA16F,gl.SAMPLES);
  const samples=Math.max(0,...Array.from(supportedSamples||[]).filter(value=>value<=4));
  composer.renderTarget1.samples=samples;composer.renderTarget2.samples=samples;
  composer.addPass(new RenderPass(scene,camera));
  bloom=new UnrealBloomPass(new THREE.Vector2(1,1),.10,.25,1.3);composer.addPass(bloom);
  composer.addPass(new OutputPass());
  await buildBadge();resize();
  await createSequence();
  renderer.setAnimationLoop(animate);
  window.badgePresentation = {
    reset,
    close(){unlockSequence?.close();},
    snapshot() {
      renderScene();
      const copy=document.createElement('canvas');
      // Full viewport during unlock; sharing retains the original badge-stage crop.
      copy.width=canvas.width;copy.height=Math.round(canvas.height*(unlockSequence&&!unlockSequence.disposed? .52:1));
      copy.getContext('2d').drawImage(canvas,0,0,canvas.width,copy.height,0,0,copy.width,copy.height);
      return copy;
    }
  };
  window.playBadgeUnlock=async()=>{
    if(unlockSequence?.state===UnlockState.PLAYING&&!unlockSequence.debugPaused)return false;
    if(unlockSequence?.disposed)return createSequence(true);
    unlockSequence.reset();return unlockSequence.play();
  };
  window.badgeUnlockDebug={
    get sequence(){return unlockSequence;},config:BADGE_UNLOCK_CONFIG,
    inspect:()=>unlockSequence.inspect(),
    seek:seconds=>unlockSequence.seek(seconds),
    reset:()=>unlockSequence.disposed?createSequence():unlockSequence.reset(),
    close:()=>unlockSequence.close(),
    memory:()=>({...renderer.info.memory}),
    fallback:()=>showFallback(),
  };
  mountUnlockDebug(window.badgeUnlockDebug);
  window.addEventListener('resize',resize,{signal:lifecycle.signal});
  resizeObserver=new ResizeObserver(resize);resizeObserver.observe(canvas);
  document.addEventListener('visibilitychange',()=>{
    previous=0;renderer.setAnimationLoop(document.hidden||canvas.hidden?null:animate);
  },{signal:lifecycle.signal});
  canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();showFallback();},{signal:lifecycle.signal});
  canvas.addEventListener('webglcontextrestored',()=>location.reload(),{signal:lifecycle.signal});
  window.addEventListener('pagehide',event=>{if(!event.persisted){unlockSequence?.dispose();resizeObserver.disconnect();lifecycle.abort();renderer.setAnimationLoop(null);}},{signal:lifecycle.signal});
} catch(error) {showFallback(error);}
